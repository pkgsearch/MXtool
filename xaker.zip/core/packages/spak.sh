pkg install pip
pip install --upgrade pip
pip install colorama
pip install telethon
clear
echo "Все пакеты установлены. При следующем запуске жмите [1]. Скрипт запустится"
python ~/px/core/tools/TGSPAM.py
