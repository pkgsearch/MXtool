# xaker
<h5>Установка:</h5>

Обновление xaker 2.0:</br>
Авто запуск </br>
Выкрашен текст </br>
Обновиться:<br>
rm -rf px</br>
pkg install wget (если не установлен) и пишем wget https://kutt.it/xaker  <br>
Запуск из любой директории:
bash ~/px/main.sh <br>
Скачать:</br>
pkg install git && pkg install python && git clone https://kutt.it/xaker ~/px/ && pip install requests</br>
Запуск из любой директории:</br>
bash ~/px/main.sh </br>
